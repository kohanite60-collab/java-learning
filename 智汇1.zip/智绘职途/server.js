const http = require("http");
const fs = require("fs/promises");
const path = require("path");
const crypto = require("crypto");

const rootDir = __dirname;
const uploadDir = path.join(rootDir, "uploads");
const dataDir = path.join(rootDir, "data");
const resourcesFile = path.join(dataDir, "resources.json");
const studentsFile = path.join(dataDir, "students.json");
const port = Number(process.env.PORT) || 3000;
const maxUploadSize = 20 * 1024 * 1024;
const contentTypes = { ".css": "text/css; charset=utf-8", ".html": "text/html; charset=utf-8", ".js": "application/javascript; charset=utf-8", ".json": "application/json; charset=utf-8", ".pdf": "application/pdf" };

async function ensureStorage() {
  await fs.mkdir(uploadDir, { recursive: true });
  await fs.mkdir(dataDir, { recursive: true });
  try { await fs.access(resourcesFile); } catch { await fs.writeFile(resourcesFile, "[]\n", "utf8"); }
  try { await fs.access(studentsFile); } catch { await fs.writeFile(studentsFile, "[]\n", "utf8"); }
}

async function readResources() {
  try { return JSON.parse(await fs.readFile(resourcesFile, "utf8")); } catch { return []; }
}

async function saveResources(resources) {
  await fs.writeFile(resourcesFile, `${JSON.stringify(resources, null, 2)}\n`, "utf8");
}

async function readStudents() {
  try { return JSON.parse(await fs.readFile(studentsFile, "utf8")); } catch { return []; }
}

async function saveStudents(students) {
  await fs.writeFile(studentsFile, `${JSON.stringify(students, null, 2)}\n`, "utf8");
}

function sendJson(response, statusCode, body) {
  response.writeHead(statusCode, { "Content-Type": "application/json; charset=utf-8" });
  response.end(JSON.stringify(body));
}

function readRequestBody(request) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let size = 0;
    request.on("data", (chunk) => {
      size += chunk.length;
      if (size > maxUploadSize) { reject(new Error("文件总大小不能超过 20MB")); request.destroy(); return; }
      chunks.push(chunk);
    });
    request.on("end", () => resolve(Buffer.concat(chunks)));
    request.on("error", reject);
  });
}

async function readJsonRequest(request) {
  const body = await readRequestBody(request);
  try { return JSON.parse(body.toString("utf8")); } catch { throw new Error("请求数据格式不正确"); }
}

function getStudentData(input) {
  const student = {
    name: String(input.name || "").trim(),
    no: String(input.no || "").trim(),
    major: String(input.major || "").trim(),
    grade: String(input.grade || "").trim(),
    intent: String(input.intent || "").trim(),
    status: String(input.status || "待跟进").trim(),
    notes: String(input.notes || "").trim(),
    updated: "刚刚"
  };
  if (!student.name || !student.no || !student.major || !student.grade) throw new Error("请完整填写姓名、学号、专业和年级");
  if (!["待跟进", "跟进中", "已完成"].includes(student.status)) throw new Error("跟进状态不正确");
  return student;
}

async function createStudent(request, response, allowUpsert = false) {
  try {
    const studentData = getStudentData(await readJsonRequest(request));
    const students = await readStudents();
    const existingIndex = students.findIndex((student) => student.no === studentData.no);
    if (existingIndex >= 0 && !allowUpsert) return sendJson(response, 409, { error: "该学号已存在，请编辑已有学生档案" });
    const student = { id: existingIndex >= 0 ? students[existingIndex].id : crypto.randomUUID(), ...studentData, serverStored: true };
    if (existingIndex >= 0) students[existingIndex] = student;
    else students.unshift(student);
    await saveStudents(students);
    sendJson(response, existingIndex >= 0 ? 200 : 201, { student });
  } catch (error) { sendJson(response, 400, { error: error.message || "保存学生档案失败" }); }
}

async function updateStudent(request, response, studentId) {
  try {
    const students = await readStudents();
    const studentIndex = students.findIndex((student) => student.id === studentId);
    if (studentIndex < 0) return sendJson(response, 404, { error: "学生档案不存在" });
    const studentData = getStudentData(await readJsonRequest(request));
    const duplicate = students.find((student) => student.no === studentData.no && student.id !== studentId);
    if (duplicate) return sendJson(response, 409, { error: "该学号已存在" });
    const student = { id: studentId, ...studentData, serverStored: true };
    students[studentIndex] = student;
    await saveStudents(students);
    sendJson(response, 200, { student });
  } catch (error) { sendJson(response, 400, { error: error.message || "更新学生档案失败" }); }
}

async function deleteStudent(studentId, response) {
  const students = await readStudents();
  if (!students.some((student) => student.id === studentId)) return sendJson(response, 404, { error: "学生档案不存在" });
  await saveStudents(students.filter((student) => student.id !== studentId));
  sendJson(response, 200, { ok: true });
}

function parseMultipart(body, boundary) {
  const separator = Buffer.from(`--${boundary}`);
  const headerSeparator = Buffer.from("\r\n\r\n");
  const parts = [];
  let cursor = body.indexOf(separator) + separator.length + 2;
  while (cursor > separator.length + 1 && cursor < body.length) {
    const nextBoundary = body.indexOf(separator, cursor);
    if (nextBoundary === -1) break;
    const headerEnd = body.indexOf(headerSeparator, cursor);
    if (headerEnd === -1 || headerEnd > nextBoundary) break;
    const headers = body.slice(cursor, headerEnd).toString("utf8");
    const content = body.slice(headerEnd + headerSeparator.length, nextBoundary - 2);
    const disposition = /content-disposition:\s*form-data;[^\r\n]*/i.exec(headers)?.[0] || "";
    const name = /name="([^"]+)"/i.exec(disposition)?.[1];
    const filename = /filename="([^"]*)"/i.exec(disposition)?.[1];
    if (name && filename) parts.push({ name, filename: path.basename(filename), content });
    cursor = nextBoundary + separator.length + 2;
  }
  return parts;
}

async function uploadResources(request, response) {
  const contentType = request.headers["content-type"] || "";
  const boundary = /boundary=([^;]+)/i.exec(contentType)?.[1]?.replace(/^"|"$/g, "");
  if (!boundary) return sendJson(response, 400, { error: "请使用 multipart/form-data 上传文件" });
  try {
    const parts = parseMultipart(await readRequestBody(request), boundary);
    const files = parts.filter((part) => part.name === "pdf" && part.filename.toLowerCase().endsWith(".pdf") && part.content.subarray(0, 1024).includes(Buffer.from("%PDF")));
    if (!files.length) return sendJson(response, 400, { error: "请选择有效的 PDF 文件" });
    const resources = await readResources();
    const created = await Promise.all(files.map(async (file) => {
      const id = crypto.randomUUID();
      const storedName = `${id}.pdf`;
      await fs.writeFile(path.join(uploadDir, storedName), file.content);
      const resource = { id, name: file.filename, tag: "就业指导", description: "本地上传的 PDF 资料，等待补充分类与摘要。", size: `${(file.content.length / 1024 / 1024).toFixed(1)} MB`, date: "刚刚", url: `/uploads/${storedName}`, serverStored: true };
      resources.unshift(resource);
      return resource;
    }));
    await saveResources(resources);
    sendJson(response, 201, { resources: created });
  } catch (error) {
    sendJson(response, 400, { error: error.message || "上传失败" });
  }
}

async function deleteResource(resourceId, response) {
  const resources = await readResources();
  const resource = resources.find((item) => item.id === resourceId);
  if (!resource) return sendJson(response, 404, { error: "资料不存在" });
  const filename = path.basename(new URL(resource.url, "http://localhost").pathname);
  await fs.unlink(path.join(uploadDir, filename)).catch(() => {});
  await saveResources(resources.filter((item) => item.id !== resourceId));
  sendJson(response, 200, { ok: true });
}

async function serveStatic(requestPath, response) {
  const requestedPath = requestPath === "/" ? "/index.html" : decodeURIComponent(requestPath);
  const filePath = path.resolve(rootDir, `.${requestedPath}`);
  if (!filePath.startsWith(rootDir + path.sep)) return sendJson(response, 403, { error: "无权访问" });
  try {
    const body = await fs.readFile(filePath);
    response.writeHead(200, { "Content-Type": contentTypes[path.extname(filePath).toLowerCase()] || "application/octet-stream", "Cache-Control": "no-store" });
    response.end(body);
  } catch { sendJson(response, 404, { error: "文件不存在" }); }
}

async function handleRequest(request, response) {
  const { pathname } = new URL(request.url, `http://${request.headers.host}`);
  if (request.method === "GET" && pathname === "/api/resources") return sendJson(response, 200, { resources: await readResources() });
  if (request.method === "POST" && pathname === "/api/resources") return uploadResources(request, response);
  if (request.method === "DELETE" && pathname.startsWith("/api/resources/")) return deleteResource(decodeURIComponent(pathname.split("/").pop()), response);
  if (request.method === "GET" && pathname === "/api/students") return sendJson(response, 200, { students: await readStudents() });
  if (request.method === "POST" && pathname === "/api/students") return createStudent(request, response);
  if (request.method === "POST" && pathname === "/api/students/migrate") return createStudent(request, response, true);
  if (request.method === "PUT" && pathname.startsWith("/api/students/")) return updateStudent(request, response, decodeURIComponent(pathname.split("/").pop()));
  if (request.method === "DELETE" && pathname.startsWith("/api/students/")) return deleteStudent(decodeURIComponent(pathname.split("/").pop()), response);
  return serveStatic(pathname, response);
}

ensureStorage().then(() => http.createServer((request, response) => { handleRequest(request, response).catch(() => sendJson(response, 500, { error: "服务器内部错误" })); }).listen(port, () => console.log(`智绘职途已启动：http://localhost:${port}`)));
