const storeKey = "career-os-demo";
const studentMigrationKey = "career-os-students-migrated";
const defaults = {
  resources: [
    { id: 1, name: "2026届毕业生就业指导手册.pdf", tag: "就业指导", description: "求职流程、简历准备与就业权益说明", size: "2.4 MB", date: "今天" },
    { id: 2, name: "人工智能行业人才趋势报告.pdf", tag: "行业报告", description: "AI 产业岗位需求与核心技能观察", size: "5.8 MB", date: "昨天" },
    { id: 3, name: "考研与留学规划指南.pdf", tag: "升学规划", description: "国内升学和海外申请时间线", size: "1.7 MB", date: "7月18日" }
  ],
  students: [
    { id: 1, name: "张晓晴", no: "2023010801", major: "软件工程", grade: "2023级", intent: "产品经理", status: "跟进中", notes: "关注互联网与AI产品岗位", updated: "今天" },
    { id: 2, name: "陈宇航", no: "2022010426", major: "金融学", grade: "2022级", intent: "数据分析师", status: "待跟进", notes: "计划秋招", updated: "昨天" },
    { id: 3, name: "林思妍", no: "2023011532", major: "视觉传达设计", grade: "2023级", intent: "品牌设计师", status: "已完成", notes: "已获得实习机会", updated: "7月19日" }
  ]
};

const persistedState = JSON.parse(localStorage.getItem(storeKey) || "null");
const hasPersistedState = Boolean(persistedState);
let state = persistedState || defaults;
let resourceFilter = "all";
let toastTimer;
const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

function persist() { localStorage.setItem(storeKey, JSON.stringify(state)); }
function escapeHtml(value = "") { return String(value).replace(/[&<>'"]/g, (char) => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", "'":"&#39;", '"':"&quot;" }[char])); }
function showToast(message) { const toast = $("#toast"); toast.textContent = message; toast.classList.remove("hidden"); clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.add("hidden"), 2400); }

function updateStats() {
  $("#statStudents").textContent = state.students.length;
  $("#statFiles").textContent = state.resources.length;
  const intentCount = state.students.filter((student) => student.intent.trim()).length;
  $("#statIntent").textContent = state.students.length ? `${Math.round(intentCount / state.students.length * 100)}%` : "0%";
  const activities = [...state.resources.slice(0, 2).map((resource) => ({ icon: "▱", title: `上传了资料《${resource.name}》`, meta: `${resource.tag} · ${resource.size}`, time: resource.date })), ...state.students.slice(0, 2).map((student) => ({ icon: "♙", title: `更新了 ${student.name} 的学生档案`, meta: `${student.major} · ${student.status}`, time: student.updated }))].slice(0, 4);
  $("#activityList").innerHTML = activities.map((item) => `<div class="activity"><span class="activity-badge">${item.icon}</span><div><strong>${escapeHtml(item.title)}</strong><small>${escapeHtml(item.meta)}</small></div><time>${escapeHtml(item.time)}</time></div>`).join("");
}

function renderResources() {
  const query = $("#resourceSearch").value.trim().toLowerCase();
  const files = state.resources.filter((file) => (resourceFilter === "all" || file.tag === resourceFilter) && [file.name, file.tag, file.description].join(" ").toLowerCase().includes(query));
  $("#fileGrid").innerHTML = files.map((file) => { const hasPreview = Boolean(file.url || file.dataUrl); return `<article class="file-card panel"><div class="file-type">PDF</div><button class="delete-file" data-delete-file="${file.id}" title="删除资料">×</button><h3 title="${escapeHtml(file.name)}">${escapeHtml(file.name)}</h3><p>${escapeHtml(file.description)}</p><div class="file-meta"><span class="tag">${escapeHtml(file.tag)}</span><span>${escapeHtml(file.size)}</span><span>·</span><span>${escapeHtml(file.date)}</span></div><div class="file-actions"><button class="preview-file" data-preview-file="${file.id}" ${hasPreview ? "" : "disabled"}>查看 PDF →</button>${hasPreview ? "" : "<small>演示资料不可预览</small>"}</div></article>`; }).join("");
  $("#fileEmpty").classList.toggle("hidden", files.length !== 0);
}

function renderStudents() {
  const query = $("#studentSearch").value.trim().toLowerCase();
  const status = $("#studentStatus").value;
  const students = state.students.filter((student) => (status === "all" || student.status === status) && [student.name, student.no, student.major, student.intent].join(" ").toLowerCase().includes(query));
  $("#studentTable").innerHTML = students.map((student) => `<tr><td><div class="student-cell"><span class="student-avatar">${escapeHtml(student.name.slice(0, 1))}</span><div><strong>${escapeHtml(student.name)}</strong><small>${escapeHtml(student.no)}</small></div></div></td><td>${escapeHtml(student.major)}<br /><small>${escapeHtml(student.grade)}</small></td><td>${escapeHtml(student.intent || "未填写")}</td><td><span class="status ${student.status}">${student.status}</span></td><td>${escapeHtml(student.updated)}</td><td class="row-actions"><button data-edit-student="${student.id}">编辑</button> <button data-delete-student="${student.id}">删除</button></td></tr>`).join("");
  $("#studentEmpty").classList.toggle("hidden", students.length !== 0);
}

function changeView(viewId) { $$(".view").forEach((view) => view.classList.toggle("active", view.id === viewId)); $$(".nav-item").forEach((button) => button.classList.toggle("active", button.dataset.view === viewId)); $("#pageTitle").textContent = ({ overview: "工作台", resources: "资料中心", students: "学生管理", agent: "智能助手" })[viewId]; window.scrollTo({ top: 0, behavior: "smooth" }); }
function openModal(student) { const form = $("#studentForm"); form.reset(); $("#studentId").value = ""; $("#studentModalTitle").textContent = student ? "编辑学生档案" : "录入学生档案"; if (student) { $("#studentId").value = student.id; $("#name").value = student.name; $("#studentNo").value = student.no; $("#major").value = student.major; $("#grade").value = student.grade; $("#careerIntent").value = student.intent; $("#followStatus").value = student.status; $("#notes").value = student.notes; } $("#studentModal").classList.remove("hidden"); $("#name").focus(); }
function closeModal() { $("#studentModal").classList.add("hidden"); }
function openPdfPreview(file) { const fileUrl = file?.url || file?.dataUrl; if (!fileUrl) return; $("#pdfModalTitle").textContent = file.name; $("#pdfPreview").src = fileUrl; $("#pdfModal").classList.remove("hidden"); }
function closePdfPreview() { $("#pdfPreview").src = ""; $("#pdfModal").classList.add("hidden"); }
async function loadServerResources() { try { const response = await fetch("/api/resources"); if (!response.ok) return; const { resources } = await response.json(); state.resources = [...resources, ...state.resources.filter((resource) => !resource.serverStored)]; persist(); updateStats(); renderResources(); } catch {} }
async function migrateLocalStudents() { if (!hasPersistedState || localStorage.getItem(studentMigrationKey)) return; const localStudents = state.students || []; try { await Promise.all(localStudents.map(async ({ id, serverStored, ...student }) => { const response = await fetch("/api/students/migrate", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(student) }); if (!response.ok) throw new Error("迁移失败"); })); localStorage.setItem(studentMigrationKey, "true"); } catch { showToast("历史学生资料迁移失败，请刷新页面重试"); } }
async function loadServerStudents() { try { await migrateLocalStudents(); const response = await fetch("/api/students"); if (!response.ok) return; const { students } = await response.json(); state.students = students; persist(); updateStats(); renderStudents(); } catch { showToast("学生资料服务不可用，请确认已执行 npm start"); } }
function agentReply(question) { const questionLower = question.toLowerCase(); let reply = "我建议先明确目标岗位，再从经历、技能和项目三个维度梳理行动计划。你也可以将学生档案与相关资料作为上下文发送给真实的智能体接口。"; if (questionLower.includes("简历")) reply = "简历应优先突出和目标岗位最匹配的成果：用量化数据描述项目贡献，并将核心技能放在第一页易读的位置。"; if (questionLower.includes("资料")) reply = `资料中心目前有 ${state.resources.length} 份文档。可以优先阅读《${state.resources[0]?.name || "就业指导手册"}》，并结合学生当前的就业意向进行规划。`; if (questionLower.includes("求职") || questionLower.includes("计划")) reply = "可按“目标定位 → 能力差距 → 项目/实习补足 → 简历投递 → 面试复盘”建立周计划，并每两周复盘一次。"; setTimeout(() => { $("#chatMessages").insertAdjacentHTML("beforeend", `<div class="message assistant"><span>✦</span><p>${reply}</p></div>`); $("#chatMessages").scrollTop = $("#chatMessages").scrollHeight; }, 430); }

function init() {
  $("#currentDate").textContent = new Intl.DateTimeFormat("zh-CN", { year: "numeric", month: "short", day: "numeric", weekday: "short" }).format(new Date());
  $$(".nav-item").forEach((button) => button.addEventListener("click", () => changeView(button.dataset.view)));
  $$('[data-goto]').forEach((button) => button.addEventListener("click", () => changeView(button.dataset.goto)));
  $("#resourceSearch").addEventListener("input", renderResources);
  $$("[data-resource-filter]").forEach((button) => button.addEventListener("click", () => { resourceFilter = button.dataset.resourceFilter; $$("[data-resource-filter]").forEach((chip) => chip.classList.toggle("active", chip === button)); renderResources(); }));
  $("#pdfUpload").addEventListener("change", async (event) => { const files = [...event.target.files]; if (!files.length) return; const rejected = files.filter((file) => !file.name.toLowerCase().endsWith(".pdf")); const accepted = files.filter((file) => file.name.toLowerCase().endsWith(".pdf")); if (!accepted.length) { showToast("仅支持上传 PDF 文件"); return; } try { const formData = new FormData(); accepted.forEach((file) => formData.append("pdf", file, file.name)); const response = await fetch("/api/resources", { method: "POST", body: formData }); const result = await response.json(); if (!response.ok) throw new Error(result.error || "上传失败"); state.resources = [...result.resources, ...state.resources]; persist(); updateStats(); renderResources(); showToast(`已上传 ${result.resources.length} 份 PDF，可点击“查看 PDF”预览${rejected.length ? "；非 PDF 文件已忽略" : ""}`); } catch (error) { showToast(`${error.message || "上传失败"}，请确认已通过 npm start 启动服务`); } finally { event.target.value = ""; } });
  $("#fileGrid").addEventListener("click", async (event) => { const deleteId = event.target.dataset.deleteFile; const previewId = event.target.dataset.previewFile; if (previewId) { openPdfPreview(state.resources.find((file) => String(file.id) === previewId)); return; } if (!deleteId) return; const file = state.resources.find((item) => String(item.id) === deleteId); try { if (file?.serverStored) { const response = await fetch(`/api/resources/${encodeURIComponent(file.id)}`, { method: "DELETE" }); if (!response.ok) throw new Error("删除服务器文件失败"); } state.resources = state.resources.filter((item) => String(item.id) !== deleteId); persist(); updateStats(); renderResources(); showToast("资料已删除"); } catch (error) { showToast(error.message || "资料删除失败"); } });
  $(".close-pdf").addEventListener("click", closePdfPreview); $("#pdfModal").addEventListener("click", (event) => { if (event.target === $("#pdfModal")) closePdfPreview(); });
  $("#studentSearch").addEventListener("input", renderStudents); $("#studentStatus").addEventListener("change", renderStudents); $("#openStudentModal").addEventListener("click", () => openModal()); $$(".close-modal").forEach((button) => button.addEventListener("click", closeModal)); $("#studentModal").addEventListener("click", (event) => { if (event.target === $("#studentModal")) closeModal(); });
  $("#studentForm").addEventListener("submit", async (event) => { event.preventDefault(); const id = $("#studentId").value; const student = { name: $("#name").value.trim(), no: $("#studentNo").value.trim(), major: $("#major").value.trim(), grade: $("#grade").value, intent: $("#careerIntent").value.trim(), status: $("#followStatus").value, notes: $("#notes").value.trim() }; try { const response = await fetch(id ? `/api/students/${encodeURIComponent(id)}` : "/api/students", { method: id ? "PUT" : "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(student) }); const result = await response.json(); if (!response.ok) throw new Error(result.error || "保存失败"); if (id) state.students = state.students.map((item) => String(item.id) === id ? result.student : item); else state.students.unshift(result.student); persist(); updateStats(); renderStudents(); closeModal(); showToast(id ? "学生档案已更新" : "学生档案已建立"); } catch (error) { showToast(`${error.message || "保存失败"}，请确认已执行 npm start`); } });
  $("#studentTable").addEventListener("click", async (event) => { const editId = event.target.dataset.editStudent; const deleteId = event.target.dataset.deleteStudent; if (editId) { openModal(state.students.find((student) => String(student.id) === editId)); return; } if (!deleteId) return; try { const response = await fetch(`/api/students/${encodeURIComponent(deleteId)}`, { method: "DELETE" }); if (!response.ok) { const result = await response.json(); throw new Error(result.error || "删除失败"); } state.students = state.students.filter((student) => String(student.id) !== deleteId); persist(); updateStats(); renderStudents(); showToast("学生档案已删除"); } catch (error) { showToast(`${error.message || "删除失败"}，请确认已执行 npm start`); } });
  $("#chatForm").addEventListener("submit", (event) => { event.preventDefault(); const input = $("#chatInput"); const question = input.value.trim(); if (!question) return; $("#chatMessages").insertAdjacentHTML("beforeend", `<div class="message user"><p>${escapeHtml(question)}</p></div>`); input.value = ""; $("#chatMessages").scrollTop = $("#chatMessages").scrollHeight; agentReply(question); });
  $$(".suggestions button").forEach((button) => button.addEventListener("click", () => { $("#chatInput").value = button.textContent; $("#chatForm").requestSubmit(); })); $("#saveConfig").addEventListener("click", () => showToast("接口配置已保存（演示模式未发起网络请求）"));
  updateStats(); renderResources(); renderStudents(); loadServerResources(); loadServerStudents();
}
init();
